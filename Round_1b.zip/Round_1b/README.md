# Round 1b: Persona-Driven Document Intelligence

This solution analyzes a collection of PDF documents to extract the most relevant sections based on a user persona and their job-to-be-done.

## How to Build the Docker Image
```sh
docker build -t Round_1b.