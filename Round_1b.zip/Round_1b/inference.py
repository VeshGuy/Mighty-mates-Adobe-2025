import os
import fitz
import json
import datetime
import numpy as np
from sentence_transformers import SentenceTransformer, util
import faiss
import re
import time
from collections import defaultdict

def parse_pdf_to_chunks(pdf_path):
    doc = fitz.open(pdf_path)
    chunks = []
    current_heading = "Introduction"
    current_text = ""
    for page in doc:
        blocks = page.get_text("dict")["blocks"]
        font_sizes = {}
        for block in blocks:
            if block['type'] == 0:
                for line in block['lines']:
                    for span in line['spans']:
                        size = round(span['size'])
                        font_sizes[size] = font_sizes.get(size, 0) + len(span['text'])
        if not font_sizes:
            continue
        para_font = max(font_sizes, key=font_sizes.get, default=10)
        for block in blocks:
            if block['type'] != 0: continue
            block_text = " ".join(span["text"] for line in block['lines'] for span in line['spans']).strip()
            if not block_text: continue
            first_span = block['lines'][0]['spans'][0]
            size = round(first_span['size'])
            is_bold = "bold" in first_span['font'].lower()
            is_heading = (size > para_font * 1.15 or (size == para_font and is_bold)) and len(block_text) < 250
            if is_heading:
                if current_text.strip():
                    chunks.append({"source_pdf": os.path.basename(pdf_path), "heading": current_heading, "text": current_text.strip(), "page": page.number + 1})
                current_heading = block_text
                current_text = ""
            else:
                current_text += block_text + "\n\n"
    if current_text.strip():
        chunks.append({"source_pdf": os.path.basename(pdf_path), "heading": current_heading, "text": current_text.strip(), "page": doc.page_count})
    return chunks

def _clean_bullet_points(text):
    cleaned_lines = [re.sub(r'^\s*[\•\*-]\s*', '', line) for line in text.split('\n')]
    return '\n'.join(cleaned_lines)

def run_persona_analysis(pdf_files, persona, job, top_k_docs=4, top_k_chunks_per_doc=5, final_top_k=7):
    model = SentenceTransformer("paraphrase-multilingual-mpnet-base-v2")
    
    chunks_by_doc = defaultdict(list)
    for pdf in pdf_files:
        chunks_by_doc[os.path.basename(pdf)].extend(parse_pdf_to_chunks(pdf))

    if not chunks_by_doc:
        return {}

    query = f"{persona} who needs to {job}"
    query_vec = model.encode([query], convert_to_numpy=True)

    doc_candidates = []
    for doc_name, chunks in chunks_by_doc.items():
        if not chunks: continue
        
        chunk_embeddings = model.encode([f"{c['heading']}: {c['text']}" for c in chunks], convert_to_numpy=True)
        scores = util.cos_sim(query_vec, chunk_embeddings)[0]

        doc_score = scores.max().item()
        
        top_chunk_indices = np.argsort(-scores)[:top_k_chunks_per_doc]
        
        top_chunks_for_doc = []
        for i in top_chunk_indices:
            chunk = chunks[i]
            chunk['score'] = scores[i].item()
            top_chunks_for_doc.append(chunk)

        doc_candidates.append({
            "doc_name": doc_name,
            "doc_score": doc_score,
            "candidate_chunks": top_chunks_for_doc
        })

    doc_candidates.sort(key=lambda x: x['doc_score'], reverse=True)
    top_docs = doc_candidates[:top_k_docs]

    global_chunk_pool = []
    for doc_data in top_docs:
        global_chunk_pool.extend(doc_data['candidate_chunks'])
    
    global_chunk_pool.sort(key=lambda x: x['score'], reverse=True)

    extracted, sub_analysis = [], []
    for rank, chunk in enumerate(global_chunk_pool[:final_top_k]):
        extracted.append({
            "document": chunk["source_pdf"], 
            "page_number": chunk["page"], 
            "section_title": chunk["heading"], 
            "importance_rank": rank + 1
        })
        if rank < 5:
            cleaned_text = _clean_bullet_points(chunk['text'])
            sub_analysis.append({
                "document": chunk["source_pdf"], 
                "refined_text": cleaned_text, 
                "page_number": chunk["page"]
            })

    return {"metadata": {"input_documents": [os.path.basename(p) for p in pdf_files], 
                         "persona": persona, "job_to_be_done": job, 
                         "processing_timestamp": datetime.datetime.now().isoformat()}, 
                         "extracted_section": extracted, 
                         "sub-section_analysis": sub_analysis
            }

if __name__ == "__main__":
    start_time = time.time()
    pdf_dir = "/app/input"
    output_dir = "/app/output"

    os.makedirs(output_dir, exist_ok=True)

    files_to_use = [f for f in os.listdir(pdf_dir) if f.lower().endswith(".pdf")]
    pdfs = [os.path.join(pdf_dir, f) for f in files_to_use]

    if not pdfs:
        print(f"No PDF files found in {pdf_dir}.")
    else:
        persona = "Travel Planner"
        job = "Plan a 4-day trip for 10 college friends, focusing on budget-friendly activities and accommodation."

        result = run_persona_analysis(pdfs, persona, job)

        output_filepath = os.path.join(output_dir, "output.json")
        with open(output_filepath, "w", encoding="utf-8") as f:
            json.dump(result, f, indent=2, ensure_ascii=False)

        total_duration = time.time() - start_time

        print(f"\nOutput saved to '{output_filepath}' in the output folder")
        print(f"Total execution time: {total_duration:.2f} seconds")