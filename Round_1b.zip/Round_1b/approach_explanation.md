# Approach Explanation: Persona-Driven Document Intelligence

Our solution is designed to function as an intelligent document analyst, moving beyond simple keyword matching to understand user intent and deliver highly relevant, prioritized insights from a collection of documents. The core of our approach is a two-pass, document-centric semantic search pipeline.

## Stage 1: PDF Parsing and Structuring

1. The pipeline begins by ingesting a collection of PDF documents. 
2. We use the PyMuPDF library to parse each document, not just as raw text, but by analyzing its structural elements. 
3. A custom heuristic identifies headings by evaluating font size, weight (bold), and text block length. This process deconstructs each PDF into a series of structured "chunks," where each chunk contains a block of text associated with its correct heading. 
This foundational step ensures that all subsequent analysis is context-aware.

## Stage 2: Two-Pass Semantic Analysis

Once the documents are structured,
1. We perform our main analysis using a sentence-transformers model (paraphrase-multilingual-mpnet-base-v2) (970MB) chosen for its strong performance in understanding semantic similarity.

### Pass 1: Document-Level Scoring

The first pass aims to identify the most relevant documents. 
1. We create a detailed query from the user's persona and job description. 
2. For each document, we calculate a "relevance score" based on its single best-matching chunk. 
3. We quickly identify the 2–3 most valuable source documents in the collection and filter out less relevant ones, preventing noise in the final output.

### Pass 2: Global Re-ranking and Final Selection

With the top documents identified, we create a candidate pool consisting of only the best sections from these high-value sources. 
1. In the second pass, we perform a global re-ranking on this curated pool. 
2. Each candidate chunk is scored individually against the detailed query, and the results are sorted to create a final, definitive importance ranking.

This two-pass methodology ensures that the final output is not just a list of topically-related sections, but a focused and logically-ordered set of insights drawn from the most authoritative documents for the user's specific task.
