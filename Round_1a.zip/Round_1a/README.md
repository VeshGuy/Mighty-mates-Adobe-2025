# Round 1A: Document Outline Extraction

This solution uses a machine learning model to analyze the structure of a PDF and extract its title and hierarchical headings (H1, H2, H3) into a structured JSON file.

## Approach

Our approach treats heading detection as a classification problem. Instead of relying on simple, brittle rules, we built a system that learns the features of a heading from data.

1.  **Feature Extraction**: The PDF is first parsed using `PyMuPDF` to extract every line of text. These lines are then grouped into logical text blocks. For each block, we engineer a set of features that describe its visual and textual properties, including:
    * `font_size` and `relative_font_size` (compared to the page average)
    * `indentation`
    * `is_title_case` and `is_all_caps`
    * `num_words`
    * `alignment_encoded` (left, center, or right)
    * `space_above` and `space_below` the block

2.  **ML-Powered Classification**: These features are fed into a pre-trained `XGBoost` classifier. The model predicts a label for each text block (e.g., "H1", "H2", "H3", or "None"). This model-based approach is robust and can adapt to various document layouts without hardcoded rules.

3.  **Post-Processing and Hierarchy Correction**: After classification, a post-processing step enforces a strict visual hierarchy. It identifies the top three unique font sizes among all predicted headings and maps them definitively to H1, H2, and H3 respectively. This ensures the final output is logical and correctly structured, even if the model's initial predictions have minor inconsistencies. The document title is identified separately using heuristics based on font size and centered alignment on the first page.

## Models and Libraries Used

* **Model**: `XGBoost` (eXtreme Gradient Boosting) Classifier, saved as `xgboost_model.pkl`.
* **Libraries**:
    * `PyMuPDF` (fitz): For robust PDF parsing and text extraction.
    * `pandas`: For organizing and handling the feature data.
    * `numpy`: For numerical operations.
    * `scikit-learn`: As a dependency for the machine learning pipeline.
    * `pickle`: For loading the pre-trained model.

## How to Build and Run

### Build the Docker Image

From the root of the `Round_1A` directory, run the following command:
```sh
docker build -t round1a-solution .