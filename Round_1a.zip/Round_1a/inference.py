import os
import fitz 
import json
import numpy as np
import pandas as pd
import pickle
from typing import List, Dict

def is_title_case(text: str) -> bool:
    """Checks if the text is in title case."""
    words = text.split()
    if not words or not words[0][0].isupper():
        return False
    
    ignore_words = {"a", "an", "the", "and", "but", "or", "for", "nor", "on", "at", "to", "from", "by", "of", "in", "with"}
    
    for word in words[1:]:
        if word.lower() not in ignore_words and not word[0].isupper():
            return False
    return True

def is_all_caps(text: str) -> bool:
    """Checks if the text is in all caps."""
    return any(c.isalpha() for c in text) and text.isupper()

def correct_heading_hierarchy(headings: list) -> list:
    """
    Corrects heading levels based on font size, ensuring only the top 3
    font sizes are mapped to H1, H2, and H3.
    """
    if not headings:
        return []

    font_sizes = sorted(list(set([h['font_size'] for h in headings])), reverse=True)
    size_to_level_map = {size: f"H{i+1}" for i, size in enumerate(font_sizes[:3])}

    corrected_outline = []
    for heading in headings:
        if heading['font_size'] in size_to_level_map:
            level = size_to_level_map[heading['font_size']]
            corrected_outline.append({
                "level": level,
                "text": heading['text'],
                "page": heading['page']
            })
    return corrected_outline

def run_inference(pdf_path: str, model, label_map: Dict) -> Dict:
    """
    Processes a single PDF file to extract its title and hierarchical outline.
    """
    doc = fitz.open(pdf_path)
    all_lines_data = []

    for page_num, page in enumerate(doc, start=1):
        page_dict = page.get_text("dict", flags=fitz.TEXTFLAGS_DICT)
        for block in page_dict.get("blocks", []):
            if block['type'] == 0:
                for line in block.get("lines", []):
                    if not line.get("spans"): continue
                    merged_text = " ".join([span["text"].strip() for span in line["spans"] if span["text"].strip()])
                    if not merged_text: continue
                    
                    all_lines_data.append({
                        "text": merged_text,
                        "bbox": line["bbox"],
                        "font_size": line["spans"][0].get("size", 0),
                        "page_number": page_num
                    })
    all_lines_data.sort(key=lambda x: (x['page_number'], x['bbox'][1]))

    text_blocks = []
    if all_lines_data:
        current_block_lines = [all_lines_data[0]]
        for i in range(len(all_lines_data) - 1):
            current_line = all_lines_data[i]
            next_line = all_lines_data[i+1]

            is_new_block = (
                next_line["page_number"] != current_line["page_number"] or
                abs(next_line["font_size"] - current_line["font_size"]) > 1 or
                (next_line["bbox"][1] - current_line["bbox"][3]) > (current_line["bbox"][3] - current_line["bbox"][1]) * 0.8
            )

            if is_new_block:
                text_blocks.append(current_block_lines)
                current_block_lines = []
            current_block_lines.append(next_line)
        
        if current_block_lines:
             text_blocks.append(current_block_lines)

    all_font_sizes = [line['font_size'] for line in all_lines_data if line['font_size'] > 0]
    global_mean_font_size = np.mean(all_font_sizes) if all_font_sizes else 12.0

    document_title = "Untitled Document"
    if text_blocks:
        page1_blocks = [b for b in text_blocks if b and b[0]["page_number"] == 1]
        if page1_blocks:
            page_width = doc[0].rect.width
            def get_center_distance(block):
                block_center_x = (block[0]['bbox'][0] + block[-1]['bbox'][2]) / 2
                return abs(block_center_x - (page_width / 2))

            candidate_blocks = [b for b in page1_blocks if b[0]['font_size'] > 10]
            if candidate_blocks:
                title_block = min(candidate_blocks, key=get_center_distance)
                document_title = " ".join([line["text"] for line in title_block]).strip()
            else:
                title_block = max(page1_blocks, key=lambda b: b[0]['font_size'])
                document_title = " ".join([line["text"] for line in title_block]).strip()
        elif text_blocks:
            document_title = " ".join([line["text"] for line in text_blocks[0]]).strip()

    predicted_headings = []
    for block_idx, block_lines in enumerate(text_blocks):
        if not block_lines: continue
        block_text = " ".join([line["text"] for line in block_lines]).strip()
        if not block_text: continue

        first_line = block_lines[0]
        page_number = first_line["page_number"]
        page_width = doc[page_number - 1].rect.width
        
        font_size = first_line["font_size"]
        indentation = first_line["bbox"][0]
        space_above = first_line["bbox"][1] - text_blocks[block_idx-1][-1]["bbox"][3] if block_idx > 0 and text_blocks[block_idx-1] and text_blocks[block_idx-1][-1]["page_number"] == page_number else 0
        space_below = text_blocks[block_idx+1][0]["bbox"][1] - block_lines[-1]["bbox"][3] if block_idx < len(text_blocks)-1 and text_blocks[block_idx+1] and text_blocks[block_idx+1][0]["page_number"] == page_number else 0
        
        block_center = (first_line["bbox"][0] + block_lines[-1]["bbox"][2]) / 2
        alignment = "left"
        if abs(block_center - page_width / 2) < (page_width * 0.20): alignment = "center"
        elif first_line["bbox"][0] > page_width * 0.6: alignment = "right"
        
        relative_font_size = font_size / global_mean_font_size if global_mean_font_size else 1.0

        features_dict = {
            "font_size": font_size, "indentation": indentation,
            "is_title_case": is_title_case(block_text), "is_all_caps": is_all_caps(block_text),
            "num_words": len(block_text.split()), "alignment_encoded": {"left": 0, "center": 1, "right": 2}.get(alignment, -1),
            "relative_font_size": relative_font_size, "space_above": space_above, "space_below": space_below
        }
        
        df_features = pd.DataFrame([features_dict], index=[0])
        pred = model.predict(df_features)[0]
        label = label_map.get(str(pred), "None")
        if len(block_text.split()) > 50: label = "None"

        if label in ["H1", "H2", "H3"]:
            predicted_headings.append({
                "text": block_text, "page": page_number,
                "font_size": font_size, "indentation": indentation
            })

    final_outline = correct_heading_hierarchy(predicted_headings)
    
    return {"title": document_title, "outline": final_outline}

if __name__ == '__main__':
    input_dir = "/app/input"
    output_dir = "/app/output"
    model_path = "/app/xgboost_model.pkl"
    label_map_path = "/app/label_encoder.json"

    os.makedirs(output_dir, exist_ok=True)

    try:
        with open(model_path, "rb") as f:
            model = pickle.load(f)
        with open(label_map_path) as f:
            label_map = {k: v for k, v in json.load(f).items()}
    except FileNotFoundError as e:
        print(f"Error: Model or label map not found. Make sure '{model_path}' and '{label_map_path}' exist. Details: {e}")
        exit()

    if not os.path.isdir(input_dir):
        print(f"Error: Input directory '{input_dir}' not found.")
    else:
        pdf_files = [f for f in os.listdir(input_dir) if f.lower().endswith(".pdf")]
        if not pdf_files:
            print("No PDF files found in the input directory.")
        
        for filename in pdf_files:
            pdf_path = os.path.join(input_dir, filename)
            
            result_data = run_inference(pdf_path, model, label_map)
            output_filename = os.path.splitext(filename)[0] + ".json"
            output_filepath = os.path.join(output_dir, output_filename)
            
            with open(output_filepath, "w", encoding="utf-8") as f:
                json.dump(result_data, f, indent=2, ensure_ascii=False)
            
            print(f"Saved output to {output_filename}")